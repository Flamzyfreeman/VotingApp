from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import InputRequired, Email, EqualTo, Length



class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), 
                            Length(min=6, max=20, message="Username must be between 6 to 20 Characters long")])
    password = PasswordField('Password', validators=[InputRequired(), Length(6)])
    remember_me = BooleanField('Remember Me')
    submit = SubmitField('Login')


class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(),
        Length(min=6, max=20, message="Username must be between 6 to 20 Characters long")])
    email = StringField('Email', validators=[InputRequired(), Email()])

    password = PasswordField('Password', validators=[
        InputRequired(), Length(6, message="Password must be 6 character long or more than")])

    confirm_password = PasswordField('Repeat Password', validators=[
        InputRequired(), EqualTo('password', message="Password Must Match!")])
    submit = SubmitField('Register')

