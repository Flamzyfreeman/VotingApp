from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, BooleanField, SubmitField, IntegerField, SelectField
from wtforms.validators import InputRequired, Email, EqualTo, Length


class CreatePoll(FlaskForm):
    title = StringField('Create Polls', validators=[InputRequired()])
    submit = SubmitField('Create')


class CreateCandidate(FlaskForm):
    first_name = StringField('First Name', validators=[InputRequired()])
    last_name = StringField('Last Name', validators=[InputRequired()])
    age = IntegerField('Age', validators=[InputRequired()])
    state = StringField('State', validators=[InputRequired()])
    picture = FileField('Candidat Picture', validators=[FileAllowed(['jpg', 'png', 'jpeg'])])
    submit = SubmitField('Add Candidate')
    
