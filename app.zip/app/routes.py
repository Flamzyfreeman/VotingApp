import os
import secrets
from functools import wraps
from flask import render_template, session, request, flash, redirect, url_for, current_app
from app.models import Post, PostLike, Poll, User, Permission, Role
from flask_login import current_user, login_required
from app.forms import CreatePoll, CreateCandidate
from app import app, db, bcrypt


def save_picture(form_picture):
    random_hex = secrets.token_hex(8)
    _, file_extention = os.path.splitext(form_picture.filename)
    picture_fn = random_hex + file_extention
    picture_path = os.path.join(current_app.root_path, 'static/candidate_images', picture_fn)
    form_picture.save(picture_path)

    return picture_fn


def permission_required(permission):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.can(permission):
                #abort(403)
                return redirect(url_for('index'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator


def admin_required(f):
    return permission_required(Permission.ADMINISTER)(f)


@app.route('/')
def home():
    polls = Poll.query.join(Post, (Poll.id == Post.poll_id)).all()
    return render_template('home.html', polls=polls)


@app.route('/like/<int:post_id>/<action>')
@login_required
def like_action(post_id, action):
    post = Post.query.filter_by(id=post_id).first_or_404()
    if action == 'like':
        current_user.like_post(post)
        db.session.commit()
    if action == 'unlike':
        current_user.unlike_post(post)
        db.session.commit()
    return redirect(request.referrer)

@app.route('/create_poll', methods=['GET', 'POST'])
@login_required
@admin_required
def create_poll():
    form = CreatePoll()
    if request.method == 'POST':
        title = form.title.data
        poll = Poll(title=title)
        db.session.add(poll)
        db.session.commit()
        flash("You have created a new Poll", 'success')
        return redirect(url_for('create_poll'))
    return render_template('admin/create_poll.html', polls='polls',  form=form, title='Add Polls')


@app.route('/poll/<int:id>')
def get_poll(id):
    get_p = Poll.query.filter_by(id=id).first_or_404()
    poll = Post.query.filter_by(poll=get_p).all()
    polls = Poll.query.join(Post, (Poll.id == Post.poll_id)).all()
    return render_template('index.html', poll=poll, polls=polls, get_p=get_p, title='Categories')


@app.route('/addcandidate', methods=['GET', 'POST'])
@login_required
@admin_required
def addcandidate():
    form = CreateCandidate()
    polls = Poll.query.all()
    if request.method == 'POST':
        first_name = form.first_name.data
        last_name = form.last_name.data
        age = form.age.data
        state = form.state.data
        gender = request.form.get('gender')
        poll = request.form.get('poll')
        image = save_picture(request.files.get('image'))

        post = Post(first_name=first_name, last_name=last_name, age=age, state=state, gender=gender, image=image,
                              poll_id=poll)
        db.session.add(post)
        db.session.commit()
        flash("You have added a new Nominee", 'success')
        return redirect(url_for('admin_panel'))
    return render_template('admin/create_candidate.html', form=form, title='Add Candidate', polls=polls)


@app.route('/vote')
def vote():
    candidates = Post.query.order_by(Post.id).all()
    polls = Poll.query.join(Post, (Poll.id == Post.poll_id)).all()
    return render_template('index.html', candidates=candidates, polls=polls)

@app.route('/candidate/<int:post_id>')
def candidate(post_id):
    post = Post.query.get_or_404(post_id)
    posts = Post.query.order_by(Post.id).all()
    polls = Poll.query.join(Post, (Poll.id == Post.poll_id)).all()
    session['username'] = current_user.username
    return render_template('single.html', post=post, posts=posts, polls=polls)


# Administration Panel
@app.route('/admin_panel')
@login_required
@admin_required
def admin_panel():
    candidates = Post.query.order_by(Post.id.desc()).all()
    user = User.query.all()
    return render_template('admin/index.html', candidates=candidates,user=user, title='Dashboard')


@app.route('/create', methods=['POST', 'GET'])
@login_required
@admin_required
def create():
    roles = Role.query.all()
    if request.method == 'POST':
        user = User.query.filter_by(
            username=request.form.get('username')).first()
        if user:
            flash("The usernamer already exist!", 'warning')
            return redirect(url_for('auth.register'))
        email = User.query.filter_by(email=request.form.get('email')).first()
        if email:
            flash("Email already exit!", 'warning')
            return redirect(url_for('auth.register'))

        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        repeat_password = request.form.get('repeatpwd')
        role = request.form.get('role')
        if password != repeat_password:
            return redirect(url_for('create'))
            flash("Password must match! Please check and try again", "warning")
        password_hash = bcrypt.generate_password_hash(password)

        users = User(username=username, email=email,
                     password=password_hash, role_id=role)
        db.session.add(users)
        db.session.commit()
        flash('New User has been created', 'success')
        return redirect(url_for('admin_panel'))
    return render_template('admin/create.html', roles=roles, title='Create User')


@app.route('/updateuser/<int:id>', methods=['POST', 'GET'])
@login_required
@admin_required
def updateuser(id):
    roles = Role.query.all()
    user = User.query.get_or_404(id)
    if request.method == "POST":
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.password = request.form.get('password')
        user.role_id = request.form.get('role')
        db.session.commit()
        flash("User updated")
        return redirect(url_for('manageuser'))
    return render_template('admin/update.html', user=user, roles=roles, title="Update User")


@app.route('/manageuser')
@login_required
@admin_required
def manageuser():
    users = User.query.order_by(User.id.desc()).all()
    return render_template('admin/users.html', users=users, title="Manage User")
